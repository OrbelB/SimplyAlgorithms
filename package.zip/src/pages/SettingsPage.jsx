import ProfileTab from "../components/settings/ProfileTab/ProfileTab";
export default function SettingsPage(){
    return(
        <div className="starting_Setting_page">
            <ProfileTab/>
        </div>
    );
}