import UnderConstruction from "../components/underconstruction/UnderConstruction";

export default function UnderConstructionPage(){
    return(
        <div className="underconstruct">
            <UnderConstruction/>
        </div>
    );
}