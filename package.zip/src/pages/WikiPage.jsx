import WikiHome from "../components/wiki/WikiHome";

export default function WikiPage() {
    return (
        <WikiHome/>
    )
}