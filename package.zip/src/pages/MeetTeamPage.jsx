import MeetTeam from "../components/meet-team/MeetTeam";

export default function MeetTeamPage() {
    return (
        <MeetTeam/>
    )
}